<div>
    <?php echo $form->clean_body;?>
</div>
<div class="span12 form-actions">
    <?php echo HTML::anchor(URL::site("admin/formbuilder"), " ← Обратно к списку форм", array("class" => "btn")); ?>
</div>
